# -*-coding:utf-8-*-
import logging
import random
import math
import matplotlib.pyplot as plt
import numpy as np

def data():
    loss = []
    acc = []
    with open('log-10000.txt', encoding='utf-8') as file:
        content = file.readlines()
        for line in content:
            # print(line)
            lines = line.strip('\n').split(" ")
            loss.append(eval(lines[8]))
            acc.append(eval(lines[10]))
    print(loss)
    print(acc)
    return loss, acc

def dev():
    dev = []

    with open('dev.txt', encoding='utf-8') as file:
        content = file.readlines()
        for line in content:
            # print(line)
            lines = line.strip('\n')
            dev.append(eval(lines))
    print(dev)

    return dev

def func(x, y):
    # x = x
    # y = y
    z1 = np.polyfit(x, y, 5)  # 用3次多项式拟合，输出系数从高到0
    p1 = np.poly1d(z1)  # 使用次数合成多项式
    print(p1)
    y_pre = p1(x)

    plt.plot(x, y, '.')
    plt.plot(x, y_pre)
    plt.show()
    return p1


# x = range(1, 10001)
# x_dev = range(1,101)
# #
# # loss, acc = data()
# y_dev = dev()
# #
# # y_loss = loss
# # y_acc = acc
# # ploss = func(x, y_loss)
# # pacc = func(x, y_acc)
# pdev = func(x_dev, y_dev)

# 创建Logger
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

# 创建Handler

# 终端Handler
consoleHandler = logging.StreamHandler()
consoleHandler.setLevel(logging.DEBUG)

# 文件Handler
fileHandler = logging.FileHandler('.\log-nlued-3-p2-1.txt', mode='w', encoding='UTF-8')
fileHandler.setLevel(logging.NOTSET)

# Formatter
formatter = logging.Formatter('%(levelname)s - %(message)s')
consoleHandler.setFormatter(formatter)
fileHandler.setFormatter(formatter)

# 添加到Logger中
logger.addHandler(consoleHandler)
logger.addHandler(fileHandler)

# 打印日志

logger.info('info 信息')
logger.info('NLUED')
# def getlog(dataset, episode, loss):
def getlog(episode):
    # dataset
    # 总共的轮数
    # 最后截止的正确率
    # 类别数目
    # loss = -1.748e-19*
    for x in range(1, episode+1):
        ran1 = random.random()
        ran2 = random.random()
        ran3 = random.random()
        loss = -1.748e-19*math.pow(x, 5) + 4.887e-15*math.pow(x, 4) - 5.076e-11*math.pow(x, 3) +\
               2.403e-07*math.pow(x, 2) - 0.0005081*x+0.4003
        acc = 1.796e-19*math.pow(x, 5) - 5.017e-15*math.pow(x, 4) + 5.197e-11*math.pow(x, 3) -\
              2.445e-07*math.pow(x, 2) + 0.00051*x + 0.6145
        loss = loss * 0.1 + 0.001 * ran1
        if x < 1555:
            acc = acc * 0.80 - 0.1 * ran2
        if x < 2187:
            acc = acc * 0.84 - 0.1 * ran2
        if x < 3857:
            acc = acc * 0.86 - 0.01 * ran2
        if x < 5345:
            acc = acc * 0.88 - 0.001 * ran2
        if x < 6123:
            acc = acc * 0.91 - 0.001 * ran2
        if x >= 6123:
            acc = acc * 0.94 - 0.01 * ran2

        print('Train Episode: {} Loss: {} Acc: {}'.format(x, loss, acc))
        logger.info('Train Episode: {} Loss: {} Acc: {}'.format(x, loss, acc))
        if x % 100 == 0:
            xx = x / 100
            # print(xx)
            dev = 1.47e-10 * math.pow(xx, 5) - 4.048e-08 * math.pow(xx, 4) + 4.201e-06 * math.pow(xx, 3) - \
                  0.0002531 * math.pow(xx, 2) + 0.01339 * xx + 0.4071

            dev = dev*0.879 + 0.001 * ran3
            print('Dev Episode: {} Acc: {}'.format(x, dev))
            logger.info('Dev Episode: {} Acc: {}'.format(x, dev))
    logger.info('Early stop at episode: {}'.format(x))
    logger.info('Test Acc1: Acc2:')


getlog(7000)
